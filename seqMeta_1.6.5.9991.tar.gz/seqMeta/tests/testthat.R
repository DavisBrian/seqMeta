library(testthat)
library(seqMeta)

test_check("seqMeta")
