context("other bug fixes")

#data(seqMetaExample)

###########
# ISSUE N #
###########
## Template


###########
# ISSUE 3 #
###########
## Binomial imputation bug

###########
# ISSUE 2 #
###########
# test-issue2.R

###########
# ISSUE 1 #
###########
# test-issue1.R